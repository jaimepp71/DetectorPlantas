# DetectorPlantas
En el repositorio nos encontramos con todos los archivos utilizados
para crear el algoritmo y la aplicación para la detección de
plantas / flores.
